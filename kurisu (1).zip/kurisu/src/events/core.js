'use strict';
const { Events, ActivityType } = require('discord.js');
const repo = require('../database/repo');
const raid = require('../engines/raid');
const recovery = require('../engines/recovery');
const antinuke = require('../engines/antinuke');
const { validateEmojis } = require('../config/emojis');
const ui = require('../components/common/ui');
const help = require('../components/help');
const dashboard = require('../components/dashboard');
const confirm = require('../components/common/confirm');
const warnings = require('../commands/moderation/warnings');
const { deployCommands } = require('../utils/deploy');
const { describeError } = require('../utils/helpers');
const log = require('../utils/logger');

const SNAPSHOT_EVERY = 10 * 60 * 1000;

function snapshotAll(client) {
  for (const guild of client.guilds.cache.values()) {
    try {
      // Do not capture state while an incident is fresh: it may be the attacker's state.
      if (repo.recentIncidentSince(guild.id, Date.now() - 15 * 60 * 1000)) continue;
      recovery.snapshotGuild(guild);
    } catch (err) { log.warn(`snapshot failed for ${guild.id}`, err); }
  }
}

async function safeReply(interaction, line) {
  try {
    if (interaction.deferred || interaction.replied) await interaction.editReply(ui.edit([`${ui.E.redDot} ${line}`]));
    else await interaction.reply(ui.error(line));
  } catch (err) {
    if (![10062, 40060].includes(err.code)) log.warn('could not deliver error reply', err);
  }
}

const ROUTES = { kh: help.handle, ks: dashboard.handle, kc: confirm.handle, kw: warnings.component };

module.exports = [
  {
    name: Events.ClientReady, once: true,
    async execute(client) {
      log.info(`logged in as ${client.user.tag} in ${client.guilds.cache.size} guild(s)`);
      for (const g of client.guilds.cache.values()) repo.ensureGuild(g.id);
      const problems = await validateEmojis(client).catch((e) => [`validation failed: ${e.message}`]);
      if (problems.length) log.warn(`emoji registry problems (${problems.length})`, problems);
      else log.info('emoji registry validated');
      if (process.env.AUTO_DEPLOY === 'true') await deployCommands(client.commands).catch((e) => log.error('command deploy failed', e));
      client.user.setPresence({ activities: [{ name: '/help · Kurisu Security', type: ActivityType.Watching }], status: 'online' });
      snapshotAll(client);
      client.timers = [
        setInterval(() => raid.tick(client).catch((e) => log.error('raid tick failed', e)), 30_000),
        setInterval(() => snapshotAll(client), SNAPSHOT_EVERY),
      ];
      await raid.tick(client).catch(() => {}); // resolves lockdowns that expired while offline
    },
  },
  { name: Events.GuildCreate, async execute(guild) { repo.ensureGuild(guild.id); try { recovery.snapshotGuild(guild); } catch (e) { log.warn('snapshot failed', e); } } },
  {
    name: Events.InteractionCreate,
    async execute(interaction) {
      try {
        if (interaction.isChatInputCommand()) {
          const cmd = interaction.client.commands.get(interaction.commandName);
          if (!cmd) return safeReply(interaction, 'Unknown command.');
          return await cmd.execute(interaction);
        }
        if (interaction.isAutocomplete()) {
          const cmd = interaction.client.commands.get(interaction.commandName);
          return cmd?.autocomplete?.(interaction);
        }
        if (interaction.isMessageComponent() || interaction.isModalSubmit()) {
          const handler = ROUTES[interaction.customId.split(':')[0]];
          if (handler) return await handler(interaction);
        }
      } catch (err) {
        if ([10062, 40060].includes(err.code)) return undefined; // expired / already acknowledged
        log.error(`interaction error (${interaction.commandName || interaction.customId})`, err);
        return safeReply(interaction, describeError(err));
      }
      return undefined;
    },
  },
  { name: Events.GuildAuditLogEntryCreate, async execute(entry, guild) { await antinuke.handleAuditEntry(entry, guild); } },
  { name: Events.MessageCreate, async execute(message) { await antinuke.handleMessage(message); } },
  { name: Events.GuildMemberAdd, async execute(member) { await raid.onJoin(member); } },
  { name: Events.ChannelDelete, async execute(channel) { if (channel.guild) recovery.noteDeletedChannel(channel); } },
  { name: Events.GuildRoleDelete, async execute(role) { recovery.noteDeletedRole(role); } },
  { name: Events.Error, async execute(err) { log.error('client error', err); } },
  { name: Events.ShardDisconnect, async execute(ev, id) { log.warn(`shard ${id} disconnected`, { code: ev?.code }); } },
  { name: Events.ShardReconnecting, async execute(id) { log.info(`shard ${id} reconnecting`); } },
  { name: Events.ShardResume, async execute(id, replayed) { log.info(`shard ${id} resumed`, { replayed }); } },
];
