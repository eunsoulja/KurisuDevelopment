'use strict';
const {
  ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, SectionBuilder, ThumbnailBuilder,
  ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, UserSelectMenuBuilder, ChannelSelectMenuBuilder,
  MessageFlags, ChannelType,
} = require('discord.js');
const { EMOJIS, parseEmoji } = require('../../config/emojis');

const E = EMOJIS;
const text = (s) => new TextDisplayBuilder().setContent(String(s).slice(0, 3800));
const sep = (divider = true) => new SeparatorBuilder().setDivider(divider).setSpacing(SeparatorSpacingSize.Small);

/** Secondary (grey) button only. Never any other style. */
function btn(customId, label, { disabled = false } = {}) {
  return new ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(ButtonStyle.Secondary).setDisabled(disabled);
}
const row = (...components) => new ActionRowBuilder().addComponents(...components);
const buttons = (...bs) => row(...bs);

function select(customId, placeholder, options, { min = 1, max = 1, disabled = false } = {}) {
  const menu = new StringSelectMenuBuilder().setCustomId(customId).setPlaceholder(placeholder).setMinValues(min).setMaxValues(max).setDisabled(disabled);
  menu.addOptions(options.map((o) => {
    const opt = { label: o.label.slice(0, 100), value: o.value, default: !!o.default };
    if (o.description) opt.description = o.description.slice(0, 100);
    const em = parseEmoji(o.emoji);
    if (em) opt.emoji = em;
    return opt;
  }));
  return row(menu);
}
function userSelect(customId, placeholder, { max = 1 } = {}) {
  return row(new UserSelectMenuBuilder().setCustomId(customId).setPlaceholder(placeholder).setMinValues(1).setMaxValues(max));
}
function channelSelect(customId, placeholder) {
  return row(new ChannelSelectMenuBuilder().setCustomId(customId).setPlaceholder(placeholder)
    .setChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement).setMinValues(1).setMaxValues(1));
}

/**
 * Build a single Container from items:
 *   string               -> TextDisplay
 *   'sep' | 'sep:blank'  -> Separator (divider / spacing only)
 *   ActionRowBuilder     -> action row
 *   { section: text, thumbnail: url } | { section: text, button: ButtonBuilder }
 * No accent colour is ever set.
 */
function container(items) {
  const c = new ContainerBuilder();
  for (const it of items.filter(Boolean)) {
    if (typeof it === 'string') {
      if (it === 'sep') c.addSeparatorComponents(sep(true));
      else if (it === 'sep:blank') c.addSeparatorComponents(sep(false));
      else c.addTextDisplayComponents(text(it));
    } else if (it instanceof ActionRowBuilder) c.addActionRowComponents(it);
    else if (it.section) {
      const s = new SectionBuilder().addTextDisplayComponents(text(it.section));
      if (it.thumbnail) s.setThumbnailAccessory(new ThumbnailBuilder().setURL(it.thumbnail));
      else if (it.button) s.setButtonAccessory(it.button);
      c.addSectionComponents(s);
    }
  }
  return c;
}

const V2 = MessageFlags.IsComponentsV2;
/** Payload for a new reply / followUp / send. */
const message = (items, { ephemeral = false } = {}) => ({
  components: [container(items)],
  flags: ephemeral ? V2 | MessageFlags.Ephemeral : V2,
  allowedMentions: { parse: [] },
});
/** Payload for update() / editReply() (ephemeral flag cannot be changed on edit). */
const edit = (items) => ({ components: [container(items)], flags: V2, allowedMentions: { parse: [] } });

/** One-line compact notice, used for command feedback and errors. */
const notice = (emoji, line, opts) => message([`${emoji} ${line}`], opts);
const error = (line) => message([`${E.redDot} ${line}`], { ephemeral: true });

async function respond(interaction, payload) {
  if (interaction.deferred || interaction.replied) {
    const { flags, ...rest } = payload;
    return interaction.editReply({ ...rest, flags: V2 });
  }
  return interaction.reply(payload);
}

module.exports = { E, text, sep, btn, row, buttons, select, userSelect, channelSelect, container, message, edit, notice, error, respond, V2 };
