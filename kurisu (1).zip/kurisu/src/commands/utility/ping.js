'use strict';
const { SlashCommandBuilder } = require('discord.js');
const ui = require('../../components/common/ui');

module.exports = {
  category: 'utility', permission: 'None',
  examples: { '': '/ping' },
  data: new SlashCommandBuilder().setName('ping').setDescription('Check Kurisu\'s latency.'),
  async execute(i) { return i.reply(ui.notice(ui.E.redDot, `Gateway latency: **${Math.round(i.client.ws.ping)}ms**`, { ephemeral: true })); },
};
