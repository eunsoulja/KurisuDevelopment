'use strict';
const { SlashCommandBuilder, PermissionFlagsBits: P } = require('discord.js');
const { guard, fail } = require('../_util');
const perms = require('../../permissions');
const repo = require('../../database/repo');
const logging = require('../../engines/logging');
const ui = require('../../components/common/ui');
const { WHITELIST_LEVELS } = require('../../config/settings');

const { E } = ui;
const levelChoices = Object.entries(WHITELIST_LEVELS).map(([value, name]) => ({ name, value }));

/** Shared by the command and the dashboard so both enforce identical rules. Returns { ok, message }. */
async function addEntry(guild, actorMember, user, level) {
  const can = perms.canGrantLevel(guild, actorMember, level);
  if (!can.ok) return { ok: false, message: can.reason };
  if (user.id === guild.client.user.id) return { ok: false, message: 'Kurisu is always exempt.' };
  if (perms.isOwnerClass(guild, user.id)) return { ok: false, message: 'Owners are always exempt and need no entry.' };
  if (level === 'bot' && !user.bot) return { ok: false, message: 'The Trusted Bot level is for bot accounts only.' };
  if (level !== 'bot' && user.bot) return { ok: false, message: 'Bots can only be added as Trusted Bot.' };
  const existing = repo.getWhitelist(guild.id, user.id);
  if (existing) {
    const cur = perms.canGrantLevel(guild, actorMember, existing.level);
    if (!cur.ok) return { ok: false, message: 'You cannot change that existing entry.' };
  }
  repo.addWhitelist(guild.id, user.id, level, actorMember.id);
  await logging.send(guild, 'config', `${E.modernRules} WHITELIST UPDATED`, [`User: <@${user.id}>`, `Level: ${WHITELIST_LEVELS[level]}`, `By: <@${actorMember.id}>`]);
  return { ok: true, message: `<@${user.id}> is now **${WHITELIST_LEVELS[level]}**.` };
}
async function removeEntry(guild, actorMember, user) {
  const can = perms.canRemoveEntry(guild, actorMember, user.id);
  if (!can.ok) return { ok: false, message: can.reason };
  repo.removeWhitelist(guild.id, user.id);
  await logging.send(guild, 'config', `${E.modernRules} WHITELIST UPDATED`, [`Removed: <@${user.id}>`, `By: <@${actorMember.id}>`]);
  return { ok: true, message: `Removed <@${user.id}> from the whitelist.` };
}

function describe(guild, userId) {
  if (userId === guild.client.user.id) return 'Kurisu (always exempt)';
  if (perms.isGuildOwner(guild, userId)) return 'Server Owner (always exempt)';
  if (perms.isBotOwner(userId)) return 'Bot Owner (always exempt)';
  const e = repo.getWhitelist(guild.id, userId);
  return e ? `${WHITELIST_LEVELS[e.level]}${e.level === 'trusted_mod' ? ' (message modules only)' : ''}` : 'Not whitelisted';
}

module.exports = {
  category: 'administration', permission: 'Server Owner or Trusted Administrator',
  examples: { add: '/whitelist add user:@member level:Trusted Moderator', remove: '/whitelist remove user:@member', list: '/whitelist list', check: '/whitelist check user:@member' },
  addEntry, removeEntry,
  data: new SlashCommandBuilder().setName('whitelist').setDescription('Manage antinuke exemptions.')
    .setDefaultMemberPermissions(P.Administrator)
    .addSubcommand((s) => s.setName('add').setDescription('Add or update a trusted user.')
      .addUserOption((o) => o.setName('user').setDescription('User').setRequired(true))
      .addStringOption((o) => o.setName('level').setDescription('Trust level').setRequired(true).addChoices(...levelChoices)))
    .addSubcommand((s) => s.setName('remove').setDescription('Remove a trusted user.')
      .addUserOption((o) => o.setName('user').setDescription('User').setRequired(true)))
    .addSubcommand((s) => s.setName('list').setDescription('List trusted users.'))
    .addSubcommand((s) => s.setName('check').setDescription('Check a user\'s exemption status.')
      .addUserOption((o) => o.setName('user').setDescription('User').setRequired(true))),
  async execute(i) {
    const err = guard(i, {});
    if (err) return fail(i, err);
    if (!perms.canManageSecurity(i.guild, i.member)) return fail(i, 'Only the server owner, bot owner or a Trusted Administrator can use this.');
    const sub = i.options.getSubcommand();
    if (sub === 'add') {
      const r = await addEntry(i.guild, i.member, i.options.getUser('user', true), i.options.getString('level', true));
      return r.ok ? i.reply(ui.notice(E.modernRules, r.message, { ephemeral: true })) : fail(i, r.message);
    }
    if (sub === 'remove') {
      const r = await removeEntry(i.guild, i.member, i.options.getUser('user', true));
      return r.ok ? i.reply(ui.notice(E.modernRules, r.message, { ephemeral: true })) : fail(i, r.message);
    }
    if (sub === 'check') {
      const u = i.options.getUser('user', true);
      return i.reply(ui.message([`${E.modernRules} <@${u.id}>`, describe(i.guild, u.id)], { ephemeral: true }));
    }
    const rows = repo.listWhitelist(i.guild.id);
    const lines = rows.length ? rows.slice(0, 30).map((r) => `<@${r.user_id}> · ${WHITELIST_LEVELS[r.level]}`).join('\n') : 'No whitelist entries. Owners are always exempt.';
    return i.reply(ui.message([`### ${E.modernRules} WHITELIST`, 'sep', lines], { ephemeral: true }));
  },
};
