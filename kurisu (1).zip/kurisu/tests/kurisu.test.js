'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { AuditLogEvent } = require('discord.js');
const { fakeGuild, walk } = require('./helpers');

process.env.OWNER_IDS = 'botowner';
const db = require('../src/database');
db.open(':memory:');
const repo = require('../src/database/repo');
const perms = require('../src/permissions');
const antinuke = require('../src/engines/antinuke');
const { MODULES, KEYS } = require('../src/engines/antinuke/modules');
const raid = require('../src/engines/raid');
const { EMOJIS, parseEmoji } = require('../src/config/emojis');
const helpers = require('../src/utils/helpers');
const ui = require('../src/components/common/ui');
const help = require('../src/components/help');
const dashboard = require('../src/components/dashboard');
const commands = require('../src/commands').load();

test('database: migrations are idempotent and config survives a restart', () => {
  const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'kurisu-')), 'persist.db');
  const Database = require('better-sqlite3');
  // open the real module against a file, write, close, reopen
  db.close();
  db.open(file);
  repo.saveModule('gA', 'massBan', { enabled: false, threshold: 7, window_sec: 33, punishment: 'kick' });
  repo.addWhitelist('gA', 'u1', 'bypass', 'owner');
  repo.setRaid('gA', { high_joins: 42 });
  db.close();
  db.open(file);
  const m = repo.getModule('gA', 'massBan', MODULES);
  assert.equal(m.threshold, 7); assert.equal(m.enabled, 0); assert.equal(m.punishment, 'kick');
  assert.equal(repo.getWhitelist('gA', 'u1').level, 'bypass');
  assert.equal(repo.getRaid('gA').high_joins, 42);
  assert.equal(new Database(file).prepare('SELECT COUNT(*) c FROM schema_migrations').get().c, 1);
  db.close();
  db.open(':memory:');
});

test('database: guild data is isolated', () => {
  repo.addWarning('gX', 'u', 'm', 'a'); repo.addWarning('gY', 'u', 'm', 'b');
  assert.equal(repo.countWarnings('gX', 'u'), 1);
  assert.equal(repo.addCase('gX', { userId: 'u', moderatorId: 'm', action: 'ban' }).case_number, 1);
  assert.equal(repo.addCase('gY', { userId: 'u', moderatorId: 'm', action: 'ban' }).case_number, 1);
  assert.equal(repo.addCase('gX', { userId: 'u', moderatorId: 'm', action: 'kick' }).case_number, 2);
});

test('emoji registry: every entry has exact <:name:id> syntax', () => {
  for (const [k, v] of Object.entries(EMOJIS)) assert.ok(parseEmoji(v), `${k} malformed`);
  assert.ok(Object.keys(EMOJIS).length >= 30);
});

test('modules: 23 protection modules, each with defaults', () => {
  assert.equal(KEYS.length, 23);
  for (const k of KEYS) { const d = MODULES[k].defaults; assert.ok(d.threshold > 0 && d.windowSec > 0 && d.punishment, k); }
});

test('permissions: exemption rules', () => {
  const { guild } = fakeGuild();
  assert.ok(perms.isExempt(guild, 'owner'));
  assert.ok(perms.isExempt(guild, 'botowner'));
  assert.ok(perms.isExempt(guild, 'kurisu'));
  assert.ok(!perms.isExempt(guild, 'randomadmin'), 'administrator alone grants no immunity');
  repo.addWhitelist('g1', 'tm', 'trusted_mod', 'owner');
  assert.ok(!perms.isExempt(guild, 'tm', 'general'));
  assert.ok(perms.isExempt(guild, 'tm', 'message'));
  repo.addWhitelist('g1', 'byp', 'bypass', 'owner');
  assert.ok(perms.isExempt(guild, 'byp'));
});

test('permissions: whitelist authority and owner protection', () => {
  const { guild, addMember } = fakeGuild();
  const admin = addMember('ta'); admin.permissions = new (require('discord.js').PermissionsBitField)(8n);
  repo.addWhitelist('g1', 'ta', 'trusted_admin', 'owner');
  const plain = addMember('plain');
  assert.ok(perms.canGrantLevel(guild, { id: 'owner' }, 'bypass').ok);
  assert.ok(!perms.canGrantLevel(guild, admin, 'bypass').ok, 'trusted admin cannot grant bypass');
  assert.ok(!perms.canGrantLevel(guild, admin, 'trusted_admin').ok);
  assert.ok(perms.canGrantLevel(guild, admin, 'trusted_mod').ok);
  assert.ok(!perms.canGrantLevel(guild, plain, 'trusted_mod').ok, 'ordinary member cannot edit whitelist');
  assert.ok(!perms.canRemoveEntry(guild, { id: 'owner' }, 'owner').ok, 'owner protection cannot be removed');
  assert.ok(!perms.canManageSecurity(guild, plain));
  assert.ok(perms.canManageSecurity(guild, admin));
});

test('permissions: moderation hierarchy', () => {
  const { guild, addMember } = fakeGuild();
  const mod = addMember('mod', { position: 5 });
  const high = addMember('high', { position: 9 });
  const low = addMember('low', { position: 2 });
  const check = (t) => perms.checkTarget({ guild, moderator: mod, targetId: t.id, targetMember: t, verb: 'ban' });
  assert.match(check(high), /equal or higher/);
  assert.equal(check(low), null);
  assert.match(perms.checkTarget({ guild, moderator: mod, targetId: 'owner', targetMember: null, verb: 'ban' }), /owner/);
  assert.match(perms.checkTarget({ guild, moderator: mod, targetId: 'mod', targetMember: mod, verb: 'ban' }), /yourself/);
  assert.match(perms.checkTarget({ guild, moderator: mod, targetId: 'kurisu', targetMember: null, verb: 'ban' }), /myself/);
});

const entry = (id, action, executorId, extra = {}) => ({ id, action, executorId, targetId: `t${id}`, changes: [], ...extra });

test('antinuke: threshold, punishment, incident record, dedupe', async () => {
  const { guild, banned, addMember } = fakeGuild();
  addMember('attacker', { position: 3 });
  repo.ensureGuild('g1');
  await antinuke.handleAuditEntry(entry('e1', AuditLogEvent.ChannelDelete, 'attacker'), guild);
  assert.equal(banned.length, 0, 'below threshold: no punishment');
  await antinuke.handleAuditEntry(entry('e1', AuditLogEvent.ChannelDelete, 'attacker'), guild); // duplicate id
  assert.equal(banned.length, 0, 'duplicate event ignored');
  await antinuke.handleAuditEntry(entry('e2', AuditLogEvent.ChannelDelete, 'attacker'), guild);
  assert.deepEqual(banned, ['attacker']);
  const inc = repo.lastIncident('g1');
  assert.equal(inc.module, 'channelDelete'); assert.equal(inc.count, 2); assert.equal(inc.threshold, 2); assert.equal(inc.response, 'Banned');
  await antinuke.handleAuditEntry(entry('e3', AuditLogEvent.ChannelDelete, 'attacker'), guild);
  assert.equal(banned.length, 1, 'no repeat punishment inside the lock window');
  assert.equal(repo.countIncidents('g1'), 1);
});

test('antinuke: never punishes owner, bot, whitelisted users or unattributed actions', async () => {
  const { guild, banned } = fakeGuild();
  repo.addWhitelist('g1', 'friend', 'trusted_admin', 'owner');
  for (let n = 0; n < 6; n++) {
    await antinuke.handleAuditEntry(entry(`o${n}`, AuditLogEvent.ChannelDelete, 'owner'), guild);
    await antinuke.handleAuditEntry(entry(`k${n}`, AuditLogEvent.ChannelDelete, 'kurisu'), guild);
    await antinuke.handleAuditEntry(entry(`f${n}`, AuditLogEvent.ChannelDelete, 'friend'), guild);
    await antinuke.handleAuditEntry(entry(`u${n}`, AuditLogEvent.ChannelDelete, null), guild);
  }
  assert.equal(banned.length, 0);
});

test('antinuke: disabled modules do nothing', async () => {
  const { guild, banned } = fakeGuild();
  repo.saveModule('g1', 'massKick', { ...repo.getModule('g1', 'massKick', MODULES), enabled: false });
  for (let n = 0; n < 5; n++) await antinuke.handleAuditEntry(entry(`mk${n}`, AuditLogEvent.MemberKick, 'someone'), guild);
  assert.equal(banned.length, 0);
});

test('antinuke: sliding window drops old actions', () => {
  const t0 = 1_000_000;
  assert.equal(antinuke.slide('w', 10_000, 1, null, t0).total, 1);
  assert.equal(antinuke.slide('w', 10_000, 1, null, t0 + 5_000).total, 2);
  assert.equal(antinuke.slide('w', 10_000, 1, null, t0 + 20_000).total, 1);
});

test('antinuke: classification of guild update, vanity and permission escalation', () => {
  const { guild } = fakeGuild();
  const keys = (e) => antinuke.classify(e, guild).map((x) => x.key);
  assert.deepEqual(keys({ action: AuditLogEvent.GuildUpdate, changes: [{ key: 'name' }] }), ['guildUpdate']);
  assert.deepEqual(keys({ action: AuditLogEvent.GuildUpdate, changes: [{ key: 'vanity_url_code' }] }), ['vanityChange']);
  assert.deepEqual(keys({ action: AuditLogEvent.RoleUpdate, changes: [{ key: 'name' }] }), ['roleUpdate']);
  assert.deepEqual(keys({ action: AuditLogEvent.RoleUpdate, changes: [{ key: 'permissions', old: '0', new: '8' }] }).sort(), ['permEscalation', 'roleUpdate']);
  assert.deepEqual(keys({ action: AuditLogEvent.RoleUpdate, changes: [{ key: 'permissions', old: '8', new: '0' }] }), ['roleUpdate']);
  assert.deepEqual(keys({ action: AuditLogEvent.MessageBulkDelete, extra: { count: 40 } }), ['massDelete']);
});

test('raid: level thresholds', () => {
  const cfg = { elevated_joins: 5, high_joins: 10, lockdown_joins: 20 };
  assert.equal(raid.levelFor(cfg, 4), 'NORMAL');
  assert.equal(raid.levelFor(cfg, 5), 'ELEVATED');
  assert.equal(raid.levelFor(cfg, 10), 'HIGH');
  assert.equal(raid.levelFor(cfg, 25), 'LOCKDOWN');
});

test('raid: join history and detection counters persist', () => {
  repo.addJoin('gr', 'a', Date.now(), 0, true); repo.addJoin('gr', 'b', Date.now(), 0, false);
  const c = repo.countJoins('gr', Date.now() - 10_000);
  assert.equal(c.c, 2); assert.equal(c.s, 1);
});

test('helpers: duration parsing', () => {
  assert.equal(helpers.parseDuration('10m'), 600);
  assert.equal(helpers.parseDuration('1h30m'), 5400);
  assert.equal(helpers.parseDuration('2d'), 172800);
  assert.equal(helpers.parseDuration('abc'), null);
  assert.equal(helpers.parseDuration('10x'), null);
  assert.equal(helpers.formatDuration(5400), '1h 30m');
  assert.deepEqual(helpers.parseIds('1234567890123456789, 1234567890123456789 22345678901234567'), ['1234567890123456789', '22345678901234567']);
});

test('commands: all required slash commands exist', () => {
  const required = ['ban', 'unban', 'kick', 'timeout', 'untimeout', 'warn', 'warnings', 'purge', 'clear', 'slowmode', 'lock', 'unlock', 'hide', 'unhide', 'nickname', 'role', 'softban', 'massban', 'whitelist', 'security', 'help'];
  for (const r of required) assert.ok(commands.has(r), `missing /${r}`);
  const wl = commands.get('whitelist').data.toJSON().options.map((o) => o.name).sort();
  assert.deepEqual(wl, ['add', 'check', 'list', 'remove']);
  const role = commands.get('role').data.toJSON().options.map((o) => o.name).sort();
  assert.deepEqual(role, ['add', 'remove']);
});

test('help: generated from real command definitions, covers every command', () => {
  const entries = help.collect(commands);
  for (const [name, cmd] of commands) {
    const subs = cmd.data.toJSON().options.filter((o) => o.type === 1);
    if (subs.length) for (const s of subs) assert.ok(entries.some((e) => e.key === `${name}.${s.name}`), `${name} ${s.name} missing from help`);
    else assert.ok(entries.some((e) => e.key === name), `${name} missing from help`);
  }
  for (const e of entries) assert.ok(help.CATEGORIES[e.category], `${e.key} has unknown category ${e.category}`);
  const ban = entries.find((e) => e.key === 'ban');
  assert.match(help.detailView('1', entries, 'ban', 'moderation', 0).join('\n'), /USAGE[\s\S]*\/ban user:<member> reason:<text>/);
});

test('UI: Components V2, grey buttons only, no accent colour, valid payloads', () => {
  const entries = help.collect(commands);
  const g = { id: 'g1', ownerId: 'owner', client: { user: { id: 'kurisu' } } };
  const views = [help.mainView('1'), ...Object.keys(help.CATEGORIES).map((c) => help.categoryView('1', entries, c, 0)),
    ...entries.map((e) => help.detailView('1', entries, e.key, e.category, 0)),
    ...['main', 'prot', 'wl:bypass', 'logs:0', 'set', 'set:antinuke', 'raid', ...KEYS.map((k) => `mod:${k}`)].map((r) => dashboard.route(g, r))];
  for (const v of views) {
    const payload = ui.edit(v);
    const json = payload.components[0].toJSON();
    assert.equal(json.type, 17);
    assert.equal(json.accent_color, undefined, 'no accent colour');
    for (const node of walk(json)) {
      if (node.type === 2) assert.equal(node.style, 2, 'only secondary buttons');
      if (node.type === 3) assert.ok(node.options.length <= 25);
    }
    assert.ok(Number(payload.flags) & (1 << 15), 'IsComponentsV2 flag');
  }
});

test('UI: dashboard shows real database values', () => {
  const g = { id: 'gd', ownerId: 'owner', client: { user: { id: 'kurisu' } } };
  repo.addWhitelist('gd', 'u1', 'bypass', 'owner'); repo.addWhitelist('gd', 'u2', 'bypass', 'owner');
  repo.addIncident('gd', { executorId: 'x', module: 'massBan', action: 'Member Ban Add', count: 3, threshold: 3, response: 'Banned', status: 'Neutralized' });
  repo.saveModule('gd', 'massBan', { enabled: false, threshold: 3, window_sec: 15, punishment: 'ban' });
  const text = dashboard.main(g).filter((x) => typeof x === 'string').join('\n');
  assert.match(text, /KURISU SECURITY CENTER/);
  assert.match(text, /Protection Modules\s+\*\*22\/23\*\*/);
  assert.match(text, /Trusted Users\s+\*\*2\*\*/);
  assert.match(text, /Security Incidents\s+\*\*1\*\*/);
});

const fakeInteraction = (over = {}) => {
  const calls = { updated: null, replied: null };
  return {
    calls,
    customId: 'ks:v:main', guild: { id: 'gi', ownerId: 'owner', client: { user: { id: 'kurisu' } }, channels: { cache: new Map() } },
    member: { id: 'rando', permissions: { has: () => true } }, user: { id: 'rando' }, values: [],
    isFromMessage: () => false, isMessageComponent: () => true,
    update: async (p) => { calls.updated = p; }, reply: async (p) => { calls.replied = p; },
    ...over,
  };
};

test('authorization: dashboard rejects unauthorised users on every interaction type', async () => {
  for (const id of ['ks:v:main', 'ks:tog:massBan', 'ks:pun:massBan', 'ks:master:antinuke', 'ks:lclr:antinuke', 'ks:v:raid']) {
    const i = fakeInteraction({ customId: id, values: ['ban'] });
    await dashboard.handle(i);
    assert.ok(i.calls.replied, `${id} should be refused`);
    assert.equal(i.calls.updated, null, `${id} must not update`);
  }
  assert.equal(repo.getModule('gi', 'massBan', MODULES).enabled, 1, 'config unchanged');
});

test('authorization: owner can configure and changes persist', async () => {
  const owner = { id: 'owner', permissions: { has: () => true } };
  const i = fakeInteraction({ customId: 'ks:tog:massBan', member: owner, user: owner });
  await dashboard.handle(i);
  assert.ok(i.calls.updated);
  assert.equal(repo.getModule('gi', 'massBan', MODULES).enabled, 0);
  const p = fakeInteraction({ customId: 'ks:pun:massBan', member: owner, user: owner, values: ['kick'] });
  await dashboard.handle(p);
  assert.equal(repo.getModule('gi', 'massBan', MODULES).punishment, 'kick');
  const bad = fakeInteraction({ customId: 'ks:pun:massBan', member: owner, user: owner, values: ['nuke'] });
  await dashboard.handle(bad);
  assert.equal(repo.getModule('gi', 'massBan', MODULES).punishment, 'kick', 'invalid punishment rejected');
});

test('authorization: help menu belongs to the user who opened it', async () => {
  const client = { commands };
  const other = fakeInteraction({ customId: 'kh:111:main', user: { id: '222' }, client });
  await help.handle(other);
  assert.ok(other.calls.replied); assert.equal(other.calls.updated, null);
  const mine = fakeInteraction({ customId: 'kh:111:cat:moderation:0', user: { id: '111' }, client });
  await help.handle(mine);
  assert.ok(mine.calls.updated);
});

test('UI: every view fits Discord Components V2 limits', () => {
  const entries = help.collect(commands);
  const g = { id: 'gl', ownerId: 'owner', client: { user: { id: 'kurisu' } } };
  const views = [help.mainView('1'), ...Object.keys(help.CATEGORIES).flatMap((c) => [0, 1].map((p) => help.categoryView('1', entries, c, p))),
    ...['main', 'prot', 'wl:bypass', 'logs:0', 'set', 'set:antinuke', 'raid'].map((r) => dashboard.route(g, r))];
  for (const v of views) {
    const nodes = walk(ui.edit(v).components[0].toJSON());
    assert.ok(nodes.filter((x) => typeof x.type === 'number' && x.type <= 20).length <= 40, 'max 40 components');
    assert.ok(nodes.filter((x) => x.type === 10).reduce((a, x) => a + x.content.length, 0) <= 4000, 'max 4000 text chars');
  }
});
